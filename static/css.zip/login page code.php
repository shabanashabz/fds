
    <link rel="stylesheet" href="./static/css/font-awesom.css" />
    <link rel="stylesheet" href="./static/css/linearicons.css" />
    <link rel="stylesheet" href="./static/css/animate.css" />
    <link rel="stylesheet" href="./static/css/animistion.css" />
    <link rel="stylesheet" href="./static/css/login.css" />


    <script src="./static/js/jquery.js"></script>
    <script src="./static/js/animistion.js"></script>
    <script src="./static/js/login.js"></script>
    <!-- <script src="js/main.js"></script> -->
